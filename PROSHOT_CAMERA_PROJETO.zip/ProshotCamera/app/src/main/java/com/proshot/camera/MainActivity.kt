package com.proshot.camera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var cameraExecutor: ExecutorService
    private var imageCapture: ImageCapture? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var flashOn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildInterface()
        if (hasCameraPermission()) startCamera() else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 10)
    }

    private fun buildInterface() {
        val root = FrameLayout(this).apply { setBackgroundColor(0xFF080808.toInt()) }
        previewView = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 24, 18, 12)
            setBackgroundColor(0x66000000)
        }
        val brand = TextView(this).apply { text = "PROSHOT  •  AUTO"; setTextColor(-1); textSize = 16f; letterSpacing = .08f }
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val flash = makeButton("FLASH OFF") { flashOn = !flashOn; it.text = if (flashOn) "FLASH ON" else "FLASH OFF"; imageCapture?.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF }
        top.addView(flash)
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(16, 18, 16, 28)
            setBackgroundColor(0x99000000.toInt())
        }
        val switch = makeButton("VIRAR") { lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK; startCamera() }
        bottom.addView(switch)
        val shutter = Button(this).apply {
            text = "●"
            textSize = 30f
            setTextColor(0xFF111111.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFFFFFFF.toInt()))
            contentDescription = "Fotografar"
            setOnClickListener { takePhoto() }
        }
        val shutterParams = LinearLayout.LayoutParams(84, 84).apply { leftMargin = 34; rightMargin = 34 }
        bottom.addView(shutter, shutterParams)
        bottom.addView(makeButton("GALERIA") { openGallery() })
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
    }

    private fun makeButton(label: String, action: (Button) -> Unit) = Button(this).apply {
        text = label; textSize = 11f; setTextColor(-1)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(0x55333333))
        setOnClickListener { action(this) }
    }

    private fun hasCameraPermission() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setJpegQuality(100)
                .build()
            val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, preview, imageCapture)
            } catch (e: Exception) { Toast.makeText(this, "Não foi possível abrir esta câmera", Toast.LENGTH_LONG).show() }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        val name = "PROSHOT_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PROSHOT")
        }
        val options = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onError(exception: ImageCaptureException) { Toast.makeText(this@MainActivity, "Erro ao fotografar: ${exception.message}", Toast.LENGTH_LONG).show() }
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                val uri = result.savedUri
                if (uri == null) { Toast.makeText(this@MainActivity, "Foto salva", Toast.LENGTH_SHORT).show(); return }
                cameraExecutor.execute { processSavedImage(uri) }
            }
        })
    }

    // Ajuste discreto: preserva a aparência natural, com contraste local leve e nitidez moderada.
    private fun processSavedImage(uri: Uri) {
        try {
            val input = contentResolver.openInputStream(uri) ?: return
            val original = input.use { BitmapFactory.decodeStream(it) } ?: return
            val outputBitmap = naturalEnhance(original)
            val out = contentResolver.openOutputStream(uri, "w") ?: return
            out.use { outputBitmap.compress(Bitmap.CompressFormat.JPEG, 96, it) }
            if (outputBitmap !== original) outputBitmap.recycle()
            original.recycle()
            runOnUiThread { Toast.makeText(this, "Foto PROSHOT salva na galeria", Toast.LENGTH_SHORT).show() }
        } catch (_: Exception) {
            runOnUiThread { Toast.makeText(this, "Foto salva sem processamento adicional", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun naturalEnhance(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val matrix = ColorMatrix(floatArrayOf(
            1.035f, 0f, 0f, 0f, 1.2f,
            0f, 1.035f, 0f, 0f, 1.2f,
            0f, 0f, 1.035f, 0f, 1.2f,
            0f, 0f, 0f, 1f, 0f
        ))
        paint.colorFilter = ColorMatrixColorFilter(matrix)
        canvas.drawBitmap(src, 0f, 0f, paint)
        return out
    }

    private fun openGallery() {
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
            setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*")
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "Galeria não encontrada", Toast.LENGTH_SHORT).show() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startCamera()
        else Toast.makeText(this, "A permissão da câmera é necessária", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown() }
}
