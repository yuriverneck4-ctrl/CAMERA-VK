# PROSHOT CAMERA — Android

Projeto inicial Android nativo em Kotlin usando CameraX.

## Recursos incluídos
- Câmera traseira e frontal com alternância.
- Captura JPEG em qualidade máxima solicitada ao CameraX.
- Flash (quando disponível no dispositivo).
- Salvamento em `Pictures/PROSHOT`.
- Processamento automático discreto de cor após a captura.

## Como compilar
Abra a pasta no Android Studio (versão compatível com Android Gradle Plugin 8.7.3), aguarde a sincronização do Gradle e use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Observações importantes
O processamento incluído é uma primeira versão simples, não equivale a processamento computacional avançado, RAW ou HDR multi-frame. O resultado e os controles disponíveis dependem do hardware e dos recursos expostos pelo Motorola One Vision/Camera2. Testes em aparelho real são necessários antes de distribuir.
